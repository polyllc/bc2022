package polybotv1;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;

public class Watchtower {
    RobotController rc;
    public Watchtower(RobotController r){
        rc = r;
    }

    public void takeTurn() throws GameActionException {

    }
}
